# Element Bound Alpha 0.8.53 — Stable Multi-file Migration

This package is a structural migration of `ElementBound_Alpha_0.8.53_Candidate_A.html`.

## Migration rule
No intentional gameplay, AI, balance, UI, or simulation-rule changes were made. The original inline CSS and JavaScript were moved into external files in their original order. Embedded PNG assets were extracted to `assets/images/`.

## Files
- `index.html` — document structure and screen markup
- `css/game.css` — all existing CSS, in original cascade order
- `js/game.js` — all existing JavaScript, in original execution order
- `assets/images/` — PNG data-URI assets extracted from the single-file build

## Security / CSP
The original Content Security Policy only allowed inline styles/scripts. It was changed from inline-only to local same-origin (`'self'`) CSS and JavaScript so GitHub Pages can load the external files. Network connections remain blocked (`connect-src 'none'`).

## Important
Treat this as Migration Stage 1: establish a stable multi-file baseline first. Do not split `game.js` into many interdependent modules until this build passes gameplay/regression checks. Once stable, future systems such as the Deck Builder can be added as separate files without rewriting the battle engine.
